package utils;

/**
 * Created by Alex Ichim on 11.03.2017.
 */
public enum GreedyType {
    MaxValue, MinQuantity, MaxRatioValueQuantity;
}
