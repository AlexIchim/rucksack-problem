package utils;

/**
 * Created by Alex Ichim on 19.03.2017.
 */
public enum BestNeighbourType {
    MaxValue, MaxValueRation, MinQuantity;
}
